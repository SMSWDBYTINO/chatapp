'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'

type Step = 'landing' | 'register' | 'login' | 'verify'

export default function AuthPage() {
  const router = useRouter()
  const supabase = createClient()
  const [step, setStep] = useState<Step>('landing')
  const [email, setEmail] = useState('')
  const [username, setUsername] = useState('')
  const [code, setCode] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [info, setInfo] = useState('')

  async function handleRegister() {
    setError('')
    setLoading(true)
    try {
      const res = await fetch('/api/auth/send-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, username, mode: 'register' }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setInfo(`Code envoyé à ${email}`)
      setStep('verify')
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  async function handleLogin() {
    setError('')
    setLoading(true)
    try {
      const res = await fetch('/api/auth/send-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, mode: 'login' }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setInfo(`Code envoyé à ${email}`)
      setStep('verify')
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  async function handleVerify() {
    setError('')
    setLoading(true)
    try {
      const res = await fetch('/api/auth/verify-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code, username }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)

      // Verify OTP with the token_hash
      const { error: verifyError } = await supabase.auth.verifyOtp({
        token_hash: data.token_hash,
        type: 'magiclink',
      })
      if (verifyError) throw verifyError
      router.push('/chat')
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'linear-gradient(135deg, #0F0F1A 0%, #1A1A2E 100%)' }}>
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 rounded-full opacity-10" style={{ background: 'radial-gradient(circle, #6C63FF, transparent)' }}></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 rounded-full opacity-10" style={{ background: 'radial-gradient(circle, #FF6584, transparent)' }}></div>
      </div>

      <div className="w-full max-w-md relative">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4" style={{ background: 'linear-gradient(135deg, #6C63FF, #FF6584)' }}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-white">ChatApp</h1>
          <p style={{ color: '#8888AA' }} className="mt-1">Messagerie privée & sécurisée</p>
        </div>

        <div className="rounded-2xl p-6" style={{ background: '#16213E', border: '1px solid #2A2A4A' }}>
          {step === 'landing' && (
            <div className="flex flex-col gap-3">
              <h2 className="text-xl font-semibold text-white text-center mb-2">Bienvenue !</h2>
              <button onClick={() => setStep('register')}
                className="w-full py-3 px-4 rounded-xl font-semibold text-white transition-all hover:opacity-90 active:scale-95"
                style={{ background: 'linear-gradient(135deg, #6C63FF, #8B83FF)' }}>
                Créer un compte
              </button>
              <button onClick={() => setStep('login')}
                className="w-full py-3 px-4 rounded-xl font-semibold transition-all hover:opacity-90 active:scale-95"
                style={{ background: '#1A1A2E', border: '1px solid #2A2A4A', color: '#8888AA' }}>
                J'ai déjà un compte
              </button>
            </div>
          )}

          {step === 'register' && (
            <div className="flex flex-col gap-4">
              <h2 className="text-xl font-semibold text-white">Créer un compte</h2>
              <div>
                <label className="text-sm mb-1 block" style={{ color: '#8888AA' }}>Nom d'utilisateur</label>
                <input type="text" value={username} onChange={e => setUsername(e.target.value)}
                  placeholder="ex: john_doe"
                  className="w-full py-3 px-4 rounded-xl outline-none text-white placeholder-gray-600"
                  style={{ background: '#0F0F1A', border: '1px solid #2A2A4A' }} />
              </div>
              <div>
                <label className="text-sm mb-1 block" style={{ color: '#8888AA' }}>Email</label>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                  placeholder="ton@email.com"
                  className="w-full py-3 px-4 rounded-xl outline-none text-white placeholder-gray-600"
                  style={{ background: '#0F0F1A', border: '1px solid #2A2A4A' }} />
              </div>
              {error && <p className="text-red-400 text-sm">{error}</p>}
              <button onClick={handleRegister} disabled={loading || !email || !username}
                className="w-full py-3 px-4 rounded-xl font-semibold text-white transition-all hover:opacity-90 active:scale-95 disabled:opacity-50"
                style={{ background: 'linear-gradient(135deg, #6C63FF, #8B83FF)' }}>
                {loading ? 'Envoi...' : 'Recevoir le code'}
              </button>
              <button onClick={() => setStep('landing')} className="text-sm text-center" style={{ color: '#8888AA' }}>← Retour</button>
            </div>
          )}

          {step === 'login' && (
            <div className="flex flex-col gap-4">
              <h2 className="text-xl font-semibold text-white">Se connecter</h2>
              <div>
                <label className="text-sm mb-1 block" style={{ color: '#8888AA' }}>Email</label>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                  placeholder="ton@email.com"
                  className="w-full py-3 px-4 rounded-xl outline-none text-white placeholder-gray-600"
                  style={{ background: '#0F0F1A', border: '1px solid #2A2A4A' }} />
              </div>
              {error && <p className="text-red-400 text-sm">{error}</p>}
              <button onClick={handleLogin} disabled={loading || !email}
                className="w-full py-3 px-4 rounded-xl font-semibold text-white transition-all hover:opacity-90 active:scale-95 disabled:opacity-50"
                style={{ background: 'linear-gradient(135deg, #6C63FF, #8B83FF)' }}>
                {loading ? 'Envoi...' : 'Recevoir le code'}
              </button>
              <button onClick={() => setStep('landing')} className="text-sm text-center" style={{ color: '#8888AA' }}>← Retour</button>
            </div>
          )}

          {step === 'verify' && (
            <div className="flex flex-col gap-4">
              <h2 className="text-xl font-semibold text-white">Vérification</h2>
              {info && <p className="text-sm p-3 rounded-xl" style={{ background: 'rgba(108,99,255,0.1)', color: '#6C63FF' }}>{info}</p>}
              <p style={{ color: '#8888AA' }} className="text-sm">Entre le code à 6 chiffres envoyé à ton email</p>
              <input type="text" value={code}
                onChange={e => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="000000" maxLength={6}
                className="w-full py-4 px-4 rounded-xl outline-none text-white text-center text-3xl font-mono"
                style={{ background: '#0F0F1A', border: '1px solid #2A2A4A', letterSpacing: '0.5rem' }} />
              {error && <p className="text-red-400 text-sm">{error}</p>}
              <button onClick={handleVerify} disabled={loading || code.length !== 6}
                className="w-full py-3 px-4 rounded-xl font-semibold text-white transition-all hover:opacity-90 active:scale-95 disabled:opacity-50"
                style={{ background: 'linear-gradient(135deg, #6C63FF, #8B83FF)' }}>
                {loading ? 'Vérification...' : 'Confirmer'}
              </button>
              <button onClick={() => setStep('landing')} className="text-sm text-center" style={{ color: '#8888AA' }}>← Retour</button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

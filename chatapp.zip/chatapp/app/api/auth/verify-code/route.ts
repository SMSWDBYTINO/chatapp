import { NextRequest, NextResponse } from 'next/server'
import { createAdminSupabaseClient } from '@/lib/supabase-server'

export async function POST(req: NextRequest) {
  const { email, code, username } = await req.json()

  if (!email || !code) return NextResponse.json({ error: 'Email et code requis' }, { status: 400 })

  const supabase = createAdminSupabaseClient()

  // Check code
  const { data: record } = await supabase
    .from('verification_codes')
    .select('*')
    .eq('email', email)
    .eq('code', code)
    .single()

  if (!record) return NextResponse.json({ error: 'Code incorrect' }, { status: 400 })
  if (new Date(record.expires_at) < new Date()) {
    return NextResponse.json({ error: 'Code expiré, demande un nouveau' }, { status: 400 })
  }

  await supabase.from('verification_codes').delete().eq('email', email)

  // Check if user exists
  const { data: { users } } = await supabase.auth.admin.listUsers()
  const existingUser = users.find((u: any) => u.email === email)

  let userId: string

  if (existingUser) {
    userId = existingUser.id
  } else {
    const { data: newUser, error: createError } = await supabase.auth.admin.createUser({
      email,
      email_confirm: true,
    })
    if (createError || !newUser.user) {
      return NextResponse.json({ error: createError?.message || 'Erreur création compte' }, { status: 500 })
    }
    userId = newUser.user.id
    await supabase.from('profiles').insert({
      id: userId,
      email,
      username: username || email.split('@')[0],
    })
  }

  // Generate magic link to extract session
  const { data: linkData, error: linkError } = await supabase.auth.admin.generateLink({
    type: 'magiclink',
    email,
  })

  if (linkError) return NextResponse.json({ error: linkError.message }, { status: 500 })

  const url = new URL(linkData.properties.action_link)
  const token_hash = url.searchParams.get('token_hash') || ''

  return NextResponse.json({ 
    success: true,
    token_hash,
    email,
  })
}

import { NextRequest, NextResponse } from 'next/server'
import { createAdminSupabaseClient } from '@/lib/supabase-server'
import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)

export async function POST(req: NextRequest) {
  const { email, username, mode } = await req.json()

  if (!email) return NextResponse.json({ error: 'Email requis' }, { status: 400 })

  const supabase = createAdminSupabaseClient()

  // Check if user exists for login
  if (mode === 'login') {
    const { data: profile } = await supabase
      .from('profiles')
      .select('id')
      .eq('email', email)
      .single()
    if (!profile) return NextResponse.json({ error: 'Aucun compte avec cet email' }, { status: 404 })
  }

  // Check if username taken for register
  if (mode === 'register') {
    if (!username) return NextResponse.json({ error: 'Nom d\'utilisateur requis' }, { status: 400 })
    const { data: existing } = await supabase
      .from('profiles')
      .select('id')
      .eq('username', username)
      .single()
    if (existing) return NextResponse.json({ error: 'Ce nom d\'utilisateur est déjà pris' }, { status: 400 })

    const { data: existingEmail } = await supabase
      .from('profiles')
      .select('id')
      .eq('email', email)
      .single()
    if (existingEmail) return NextResponse.json({ error: 'Un compte existe déjà avec cet email' }, { status: 400 })
  }

  // Generate 6-digit code
  const code = Math.floor(100000 + Math.random() * 900000).toString()
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString()

  // Save code in DB
  await supabase.from('verification_codes').delete().eq('email', email)
  await supabase.from('verification_codes').insert({
    email,
    code,
    expires_at: expiresAt,
    username: username || null,
  })

  // Send email
  await resend.emails.send({
    from: 'ChatApp <onboarding@resend.dev>',
    to: email,
    subject: 'Ton code de vérification ChatApp',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 400px; margin: 0 auto; background: #0F0F1A; color: white; padding: 40px; border-radius: 16px;">
        <h1 style="color: #6C63FF; margin-bottom: 8px;">ChatApp</h1>
        <p style="color: #8888AA; margin-bottom: 24px;">Ton code de vérification :</p>
        <div style="background: #1A1A2E; border: 1px solid #2A2A4A; border-radius: 12px; padding: 24px; text-align: center; margin-bottom: 24px;">
          <span style="font-size: 48px; font-weight: bold; letter-spacing: 12px; color: white; font-family: monospace;">${code}</span>
        </div>
        <p style="color: #8888AA; font-size: 14px;">Ce code expire dans 10 minutes.</p>
      </div>
    `,
  })

  return NextResponse.json({ success: true })
}

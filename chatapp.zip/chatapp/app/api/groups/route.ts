import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabaseClient } from '@/lib/supabase-server'

export async function GET(req: NextRequest) {
  const supabase = createServerSupabaseClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  // Get all conversations where user is a member
  const { data, error } = await supabase
    .from('conversation_members')
    .select(`
      conversation:conversations(
        id, is_group, name, created_at,
        members:conversation_members(
          user:profiles(id, username, avatar_url)
        )
      )
    `)
    .eq('user_id', user.id)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  const conversations = data?.map((d: any) => d.conversation).filter(Boolean) || []
  return NextResponse.json(conversations)
}

export async function POST(req: NextRequest) {
  const supabase = createServerSupabaseClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  const { is_group, name, member_ids } = await req.json()

  // For private chat, check if conversation already exists
  if (!is_group && member_ids?.length === 1) {
    const otherId = member_ids[0]
    const { data: existing } = await supabase
      .from('conversation_members')
      .select('conversation_id')
      .eq('user_id', user.id)

    if (existing && existing.length > 0) {
      const myConvIds = existing.map((e: any) => e.conversation_id)
      const { data: sharedConvs } = await supabase
        .from('conversation_members')
        .select('conversation_id, conversation:conversations(is_group)')
        .eq('user_id', otherId)
        .in('conversation_id', myConvIds)

      const privateDm = sharedConvs?.find((s: any) => s.conversation?.is_group === false)
      if (privateDm) return NextResponse.json({ id: privateDm.conversation_id, existing: true })
    }
  }

  // Create conversation
  const { data: conv, error: convError } = await supabase
    .from('conversations')
    .insert({ is_group: is_group || false, name: name || null, created_by: user.id })
    .select()
    .single()

  if (convError) return NextResponse.json({ error: convError.message }, { status: 500 })

  // Add members
  const members = [user.id, ...(member_ids || [])]
  await supabase.from('conversation_members').insert(
    members.map((uid: string) => ({ conversation_id: conv.id, user_id: uid }))
  )

  return NextResponse.json(conv)
}

import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabaseClient, createAdminSupabaseClient } from '@/lib/supabase-server'

export async function POST(req: NextRequest) {
  const supabase = createServerSupabaseClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  const formData = await req.formData()
  const file = formData.get('file') as File
  if (!file) return NextResponse.json({ error: 'Fichier requis' }, { status: 400 })

  const ext = file.name.split('.').pop()
  const filename = `${user.id}/${Date.now()}.${ext}`

  const adminSupabase = createAdminSupabaseClient()
  const { data, error } = await adminSupabase.storage
    .from('chat-images')
    .upload(filename, file, { contentType: file.type })

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  const { data: urlData } = adminSupabase.storage.from('chat-images').getPublicUrl(filename)
  return NextResponse.json({ url: urlData.publicUrl })
}

import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabaseClient } from '@/lib/supabase-server'

export async function GET(req: NextRequest) {
  const supabase = createServerSupabaseClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const conversationId = searchParams.get('conversation_id')
  if (!conversationId) return NextResponse.json({ error: 'conversation_id requis' }, { status: 400 })

  const { data, error } = await supabase
    .from('messages')
    .select(`*, sender:profiles(id, username, avatar_url)`)
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true })

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

export async function POST(req: NextRequest) {
  const supabase = createServerSupabaseClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  const { conversation_id, content, image_url } = await req.json()
  if (!conversation_id) return NextResponse.json({ error: 'conversation_id requis' }, { status: 400 })
  if (!content && !image_url) return NextResponse.json({ error: 'Contenu ou image requis' }, { status: 400 })

  const { data, error } = await supabase
    .from('messages')
    .insert({ conversation_id, content: content || null, image_url: image_url || null, sender_id: user.id })
    .select(`*, sender:profiles(id, username, avatar_url)`)
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

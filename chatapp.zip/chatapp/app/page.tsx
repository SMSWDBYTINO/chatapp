'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'

export default function Home() {
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        router.push('/chat')
      } else {
        router.push('/auth')
      }
    })
  }, [])

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: '#0F0F1A' }}>
      <div className="flex flex-col items-center gap-4">
        <div className="w-12 h-12 rounded-full border-2 border-t-transparent animate-spin" style={{ borderColor: '#6C63FF', borderTopColor: 'transparent' }}></div>
        <p style={{ color: '#8888AA' }}>Chargement...</p>
      </div>
    </div>
  )
}

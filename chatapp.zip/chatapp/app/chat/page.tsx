'use client'

import { useEffect, useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'
import type { User, Conversation, Message } from '@/lib/types'

export default function ChatPage() {
  const router = useRouter()
  const supabase = createClient()
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [selectedConv, setSelectedConv] = useState<Conversation | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [sending, setSending] = useState(false)
  const [showNewChat, setShowNewChat] = useState(false)
  const [showNewGroup, setShowNewGroup] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<User[]>([])
  const [groupName, setGroupName] = useState('')
  const [selectedUsers, setSelectedUsers] = useState<User[]>([])
  const [uploading, setUploading] = useState(false)
  const [showSidebar, setShowSidebar] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (!session) { router.push('/auth'); return }
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', session.user.id)
        .single()
      if (profile) setCurrentUser(profile)
      loadConversations()
    })
  }, [])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  useEffect(() => {
    if (!selectedConv) return
    loadMessages(selectedConv.id)
    const channel = supabase
      .channel(`conv-${selectedConv.id}`)
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'messages',
        filter: `conversation_id=eq.${selectedConv.id}`
      }, async (payload) => {
        const { data: msg } = await supabase
          .from('messages')
          .select('*, sender:profiles(id, username, avatar_url)')
          .eq('id', payload.new.id)
          .single()
        if (msg) setMessages(prev => [...prev, msg])
      })
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [selectedConv])

  useEffect(() => {
    if (searchQuery.length < 2) { setSearchResults([]); return }
    const t = setTimeout(async () => {
      const res = await fetch(`/api/users?q=${searchQuery}`)
      const data = await res.json()
      setSearchResults(Array.isArray(data) ? data : [])
    }, 300)
    return () => clearTimeout(t)
  }, [searchQuery])

  async function loadConversations() {
    const res = await fetch('/api/groups')
    const data = await res.json()
    if (Array.isArray(data)) setConversations(data)
  }

  async function loadMessages(convId: string) {
    const res = await fetch(`/api/messages?conversation_id=${convId}`)
    const data = await res.json()
    if (Array.isArray(data)) setMessages(data)
  }

  async function sendMessage() {
    if (!newMessage.trim() || !selectedConv || sending) return
    setSending(true)
    const content = newMessage.trim()
    setNewMessage('')
    await fetch('/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ conversation_id: selectedConv.id, content }),
    })
    setSending(false)
  }

  async function sendImage(file: File) {
    if (!selectedConv) return
    setUploading(true)
    const form = new FormData()
    form.append('file', file)
    const uploadRes = await fetch('/api/upload', { method: 'POST', body: form })
    const { url } = await uploadRes.json()
    if (url) {
      await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ conversation_id: selectedConv.id, image_url: url }),
      })
    }
    setUploading(false)
  }

  async function startPrivateChat(user: User) {
    const res = await fetch('/api/groups', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_group: false, member_ids: [user.id] }),
    })
    const conv = await res.json()
    setShowNewChat(false)
    setSearchQuery('')
    await loadConversations()
    setSelectedConv(conv)
    setShowSidebar(false)
  }

  async function createGroup() {
    if (!groupName.trim() || selectedUsers.length < 1) return
    const res = await fetch('/api/groups', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_group: true, name: groupName, member_ids: selectedUsers.map(u => u.id) }),
    })
    const conv = await res.json()
    setShowNewGroup(false)
    setGroupName('')
    setSelectedUsers([])
    await loadConversations()
    setSelectedConv(conv)
    setShowSidebar(false)
  }

  function getConvName(conv: Conversation): string {
    if (conv.is_group) return conv.name || 'Groupe'
    const other = conv.members?.find(m => m.user?.id !== currentUser?.id)
    return other?.user?.username || 'Utilisateur'
  }

  function getConvInitial(conv: Conversation): string {
    return getConvName(conv).charAt(0).toUpperCase()
  }

  async function handleLogout() {
    await supabase.auth.signOut()
    router.push('/auth')
  }

  return (
    <div className="flex h-screen" style={{ background: '#0F0F1A' }}>
      {/* Sidebar */}
      <div className={`${showSidebar ? 'flex' : 'hidden'} md:flex flex-col w-full md:w-80 border-r`} style={{ borderColor: '#2A2A4A', background: '#0F0F1A' }}>
        {/* Header */}
        <div className="p-4 flex items-center justify-between border-b" style={{ borderColor: '#2A2A4A' }}>
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm" style={{ background: 'linear-gradient(135deg, #6C63FF, #FF6584)', color: 'white' }}>
              {currentUser?.username?.charAt(0).toUpperCase()}
            </div>
            <span className="font-semibold text-white text-sm">{currentUser?.username}</span>
          </div>
          <div className="flex gap-2">
            <button onClick={() => { setShowNewChat(true); setShowNewGroup(false) }}
              className="w-8 h-8 rounded-lg flex items-center justify-center hover:opacity-80 transition-opacity"
              style={{ background: '#1A1A2E', border: '1px solid #2A2A4A' }} title="Nouveau message">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6C63FF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                <line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line>
              </svg>
            </button>
            <button onClick={() => { setShowNewGroup(true); setShowNewChat(false) }}
              className="w-8 h-8 rounded-lg flex items-center justify-center hover:opacity-80 transition-opacity"
              style={{ background: '#1A1A2E', border: '1px solid #2A2A4A' }} title="Nouveau groupe">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#FF6584" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                <circle cx="9" cy="7" r="4"></circle>
                <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
              </svg>
            </button>
            <button onClick={handleLogout}
              className="w-8 h-8 rounded-lg flex items-center justify-center hover:opacity-80 transition-opacity"
              style={{ background: '#1A1A2E', border: '1px solid #2A2A4A' }} title="Déconnexion">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8888AA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                <polyline points="16 17 21 12 16 7"></polyline>
                <line x1="21" y1="12" x2="9" y2="12"></line>
              </svg>
            </button>
          </div>
        </div>

        {/* New chat search */}
        {showNewChat && (
          <div className="p-3 border-b" style={{ borderColor: '#2A2A4A', background: '#16213E' }}>
            <p className="text-xs font-semibold mb-2" style={{ color: '#6C63FF' }}>NOUVEAU MESSAGE</p>
            <input
              type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
              placeholder="Chercher un utilisateur..."
              className="w-full py-2 px-3 rounded-lg text-sm outline-none text-white placeholder-gray-600"
              style={{ background: '#0F0F1A', border: '1px solid #2A2A4A' }}
              autoFocus
            />
            {searchResults.map(u => (
              <div key={u.id} onClick={() => startPrivateChat(u)}
                className="flex items-center gap-2 p-2 mt-1 rounded-lg cursor-pointer hover:opacity-80 transition-opacity"
                style={{ background: '#0F0F1A' }}>
                <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold" style={{ background: 'linear-gradient(135deg, #6C63FF, #FF6584)', color: 'white' }}>
                  {u.username.charAt(0).toUpperCase()}
                </div>
                <span className="text-sm text-white">{u.username}</span>
              </div>
            ))}
            <button onClick={() => { setShowNewChat(false); setSearchQuery('') }} className="text-xs mt-2" style={{ color: '#8888AA' }}>Annuler</button>
          </div>
        )}

        {/* New group */}
        {showNewGroup && (
          <div className="p-3 border-b" style={{ borderColor: '#2A2A4A', background: '#16213E' }}>
            <p className="text-xs font-semibold mb-2" style={{ color: '#FF6584' }}>NOUVEAU GROUPE</p>
            <input type="text" value={groupName} onChange={e => setGroupName(e.target.value)}
              placeholder="Nom du groupe"
              className="w-full py-2 px-3 rounded-lg text-sm outline-none text-white placeholder-gray-600 mb-2"
              style={{ background: '#0F0F1A', border: '1px solid #2A2A4A' }} />
            <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
              placeholder="Ajouter des membres..."
              className="w-full py-2 px-3 rounded-lg text-sm outline-none text-white placeholder-gray-600"
              style={{ background: '#0F0F1A', border: '1px solid #2A2A4A' }} />
            {selectedUsers.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {selectedUsers.map(u => (
                  <span key={u.id} onClick={() => setSelectedUsers(prev => prev.filter(x => x.id !== u.id))}
                    className="text-xs px-2 py-1 rounded-full cursor-pointer flex items-center gap-1"
                    style={{ background: 'rgba(108,99,255,0.2)', color: '#6C63FF', border: '1px solid #6C63FF' }}>
                    {u.username} ×
                  </span>
                ))}
              </div>
            )}
            {searchResults.filter(u => !selectedUsers.find(s => s.id === u.id)).map(u => (
              <div key={u.id} onClick={() => { setSelectedUsers(prev => [...prev, u]); setSearchQuery('') }}
                className="flex items-center gap-2 p-2 mt-1 rounded-lg cursor-pointer hover:opacity-80"
                style={{ background: '#0F0F1A' }}>
                <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold" style={{ background: 'linear-gradient(135deg, #6C63FF, #FF6584)', color: 'white' }}>
                  {u.username.charAt(0).toUpperCase()}
                </div>
                <span className="text-sm text-white">{u.username}</span>
              </div>
            ))}
            <div className="flex gap-2 mt-2">
              <button onClick={createGroup} disabled={!groupName || selectedUsers.length < 1}
                className="flex-1 py-1.5 rounded-lg text-xs font-semibold text-white disabled:opacity-50"
                style={{ background: 'linear-gradient(135deg, #6C63FF, #FF6584)' }}>
                Créer
              </button>
              <button onClick={() => { setShowNewGroup(false); setSearchQuery(''); setSelectedUsers([]); setGroupName('') }}
                className="text-xs px-3 py-1.5 rounded-lg" style={{ background: '#0F0F1A', color: '#8888AA' }}>
                Annuler
              </button>
            </div>
          </div>
        )}

        {/* Conversations list */}
        <div className="flex-1 overflow-y-auto">
          {conversations.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full p-6 text-center">
              <div className="w-12 h-12 rounded-full flex items-center justify-center mb-3" style={{ background: '#1A1A2E' }}>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#8888AA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
              </div>
              <p className="text-sm" style={{ color: '#8888AA' }}>Aucune conversation</p>
              <p className="text-xs mt-1" style={{ color: '#4A4A6A' }}>Clique sur + pour commencer</p>
            </div>
          ) : (
            conversations.map(conv => (
              <div key={conv.id}
                onClick={() => { setSelectedConv(conv); setShowSidebar(false); setShowNewChat(false); setShowNewGroup(false) }}
                className="flex items-center gap-3 p-4 cursor-pointer transition-all border-b"
                style={{
                  borderColor: '#2A2A4A',
                  background: selectedConv?.id === conv.id ? '#1A1A2E' : 'transparent',
                }}>
                <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold flex-shrink-0"
                  style={{ background: conv.is_group ? 'linear-gradient(135deg, #FF6584, #FF8E53)' : 'linear-gradient(135deg, #6C63FF, #8B83FF)', color: 'white' }}>
                  {conv.is_group ? '👥' : getConvInitial(conv)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-white text-sm truncate">{getConvName(conv)}</p>
                  {conv.is_group && (
                    <p className="text-xs truncate" style={{ color: '#8888AA' }}>
                      {conv.members?.length} membres
                    </p>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Chat area */}
      <div className={`${showSidebar ? 'hidden' : 'flex'} md:flex flex-1 flex-col`}>
        {!selectedConv ? (
          <div className="flex-1 flex flex-col items-center justify-center" style={{ background: '#0F0F1A' }}>
            <div className="w-20 h-20 rounded-2xl flex items-center justify-center mb-4" style={{ background: 'linear-gradient(135deg, #6C63FF, #FF6584)' }}>
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
            </div>
            <h2 className="text-xl font-bold text-white mb-2">ChatApp</h2>
            <p style={{ color: '#8888AA' }} className="text-sm">Sélectionne une conversation</p>
          </div>
        ) : (
          <>
            {/* Chat header */}
            <div className="p-4 flex items-center gap-3 border-b" style={{ borderColor: '#2A2A4A', background: '#0F0F1A' }}>
              <button onClick={() => setShowSidebar(true)} className="md:hidden mr-1" style={{ color: '#8888AA' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
              </button>
              <div className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0"
                style={{ background: selectedConv.is_group ? 'linear-gradient(135deg, #FF6584, #FF8E53)' : 'linear-gradient(135deg, #6C63FF, #8B83FF)', color: 'white' }}>
                {selectedConv.is_group ? '👥' : getConvInitial(selectedConv)}
              </div>
              <div>
                <p className="font-semibold text-white text-sm">{getConvName(selectedConv)}</p>
                {selectedConv.is_group && (
                  <p className="text-xs" style={{ color: '#8888AA' }}>{selectedConv.members?.length} membres</p>
                )}
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-2" style={{ background: '#0F0F1A' }}>
              {messages.length === 0 && (
                <div className="flex-1 flex items-center justify-center">
                  <p className="text-sm" style={{ color: '#4A4A6A' }}>Aucun message. Commencez la conversation !</p>
                </div>
              )}
              {messages.map((msg, i) => {
                const isMine = msg.sender_id === currentUser?.id
                return (
                  <div key={msg.id} className={`flex ${isMine ? 'justify-end' : 'justify-start'} animate-fade-in-up`}>
                    <div className={`max-w-xs lg:max-w-md ${isMine ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
                      {!isMine && selectedConv.is_group && (
                        <span className="text-xs px-1" style={{ color: '#6C63FF' }}>{msg.sender?.username}</span>
                      )}
                      <div className={`px-4 py-2 ${isMine ? 'message-bubble-sent' : 'message-bubble-received'}`}>
                        {msg.image_url ? (
                          <img src={msg.image_url} alt="image" className="rounded-lg max-w-full" style={{ maxHeight: 300 }} />
                        ) : (
                          <p className="text-sm text-white">{msg.content}</p>
                        )}
                      </div>
                      <span className="text-xs px-1" style={{ color: '#4A4A6A' }}>
                        {new Date(msg.created_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                )
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 border-t flex items-center gap-3" style={{ borderColor: '#2A2A4A', background: '#0F0F1A' }}>
              <input type="file" ref={fileInputRef} accept="image/*" className="hidden"
                onChange={e => e.target.files?.[0] && sendImage(e.target.files[0])} />
              <button onClick={() => fileInputRef.current?.click()} disabled={uploading}
                className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-opacity hover:opacity-80 disabled:opacity-50"
                style={{ background: '#1A1A2E', border: '1px solid #2A2A4A' }}>
                {uploading ? (
                  <div className="w-4 h-4 rounded-full border-2 animate-spin" style={{ borderColor: '#6C63FF', borderTopColor: 'transparent' }}></div>
                ) : (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#8888AA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                    <circle cx="8.5" cy="8.5" r="1.5"></circle>
                    <polyline points="21 15 16 10 5 21"></polyline>
                  </svg>
                )}
              </button>
              <input type="text" value={newMessage}
                onChange={e => setNewMessage(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage()}
                placeholder="Écris un message..."
                className="flex-1 py-3 px-4 rounded-xl outline-none text-white placeholder-gray-600 text-sm"
                style={{ background: '#1A1A2E', border: '1px solid #2A2A4A' }}
              />
              <button onClick={sendMessage} disabled={sending || !newMessage.trim()}
                className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all hover:opacity-90 active:scale-95 disabled:opacity-50"
                style={{ background: 'linear-gradient(135deg, #6C63FF, #8B83FF)' }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="22" y1="2" x2="11" y2="13"></line>
                  <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                </svg>
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

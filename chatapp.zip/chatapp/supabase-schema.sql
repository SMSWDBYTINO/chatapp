-- ============================================
-- CHATAPP - Script SQL pour Supabase
-- Colle tout ce texte dans l'éditeur SQL de Supabase et clique "Run"
-- ============================================

-- Table des profils utilisateurs
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE NOT NULL,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table des codes de vérification
CREATE TABLE IF NOT EXISTS verification_codes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  code TEXT NOT NULL,
  username TEXT,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table des conversations (privées ou groupes)
CREATE TABLE IF NOT EXISTS conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  is_group BOOLEAN DEFAULT FALSE,
  name TEXT,
  created_by UUID REFERENCES profiles(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table des membres de conversations
CREATE TABLE IF NOT EXISTS conversation_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID REFERENCES conversations(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  joined_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(conversation_id, user_id)
);

-- Table des messages
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  content TEXT,
  image_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- SÉCURITÉ (RLS - Row Level Security)
-- ============================================

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversation_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Profiles: lecture publique, modification uniquement de son propre profil
CREATE POLICY "Profiles lisibles par tous" ON profiles FOR SELECT USING (true);
CREATE POLICY "Modifier son propre profil" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Créer son propre profil" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- Conversations: visible seulement si membre
CREATE POLICY "Voir ses conversations" ON conversations FOR SELECT
  USING (id IN (SELECT conversation_id FROM conversation_members WHERE user_id = auth.uid()));

CREATE POLICY "Créer une conversation" ON conversations FOR INSERT
  WITH CHECK (auth.uid() = created_by);

-- Membres: visible seulement si membre de la même conv
CREATE POLICY "Voir membres de ses conversations" ON conversation_members FOR SELECT
  USING (conversation_id IN (SELECT conversation_id FROM conversation_members WHERE user_id = auth.uid()));

CREATE POLICY "Rejoindre une conversation" ON conversation_members FOR INSERT
  WITH CHECK (true);

-- Messages: visible seulement si membre de la conversation
CREATE POLICY "Voir messages de ses conversations" ON messages FOR SELECT
  USING (conversation_id IN (SELECT conversation_id FROM conversation_members WHERE user_id = auth.uid()));

CREATE POLICY "Envoyer des messages" ON messages FOR INSERT
  WITH CHECK (
    auth.uid() = sender_id AND
    conversation_id IN (SELECT conversation_id FROM conversation_members WHERE user_id = auth.uid())
  );

-- Codes de vérification: pas de RLS (géré par service_role uniquement)
ALTER TABLE verification_codes DISABLE ROW LEVEL SECURITY;

-- ============================================
-- STORAGE - Bucket pour les images
-- ============================================

INSERT INTO storage.buckets (id, name, public) 
VALUES ('chat-images', 'chat-images', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Images publiques" ON storage.objects FOR SELECT
  USING (bucket_id = 'chat-images');

CREATE POLICY "Upload images authentifié" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'chat-images' AND auth.role() = 'authenticated');

-- ============================================
-- REALTIME - Activer pour les messages
-- ============================================

ALTER PUBLICATION supabase_realtime ADD TABLE messages;

-- FIN DU SCRIPT
SELECT 'Script exécuté avec succès ! ✅' as message;

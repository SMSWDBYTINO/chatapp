export interface User {
  id: string
  email: string
  username: string
  avatar_url?: string
  created_at: string
}

export interface Message {
  id: string
  content: string | null
  image_url: string | null
  sender_id: string
  conversation_id: string
  created_at: string
  sender?: User
}

export interface Conversation {
  id: string
  is_group: boolean
  name: string | null
  created_by: string
  created_at: string
  members?: ConversationMember[]
  last_message?: Message
}

export interface ConversationMember {
  id: string
  conversation_id: string
  user_id: string
  joined_at: string
  user?: User
}

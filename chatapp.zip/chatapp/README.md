# ChatApp 💬

Application de messagerie privée - messages, photos, groupes.

## 🚀 Déploiement en 5 étapes

### Étape 1 : Configurer Supabase

1. Va sur [supabase.com](https://supabase.com) → ton projet
2. Dans le menu gauche, clique sur **"SQL Editor"**
3. Clique **"New query"**
4. Copie tout le contenu du fichier `supabase-schema.sql`
5. Colle-le dans l'éditeur et clique **"Run"**
6. Tu dois voir : `Script exécuté avec succès ! ✅`

### Étape 2 : Récupérer tes clés

**Sur Supabase :**
- Menu gauche → **"Project Settings"** → **"API"**
- Copie :
  - `Project URL` → ex: `https://xxxxx.supabase.co`
  - `anon public` → la clé publique
  - `service_role` → la clé secrète (garde-la précieusement !)

**Sur Resend :**
- Menu gauche → **"API Keys"**
- Clique **"Create API Key"**
- Copie la clé (commence par `re_...`)

### Étape 3 : Mettre le code sur GitHub

1. Va sur [github.com](https://github.com) → clique **"New repository"**
2. Nomme-le `chatapp` → clique **"Create repository"**
3. Sur ton ordinateur, installe [Git](https://git-scm.com) si pas déjà fait
4. Dans un terminal, dans le dossier `chatapp` :
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/TON_USERNAME/chatapp.git
git push -u origin main
```

### Étape 4 : Déployer sur Vercel

1. Va sur [vercel.com](https://vercel.com) → **"Sign up with GitHub"**
2. Clique **"Add New Project"** → importe ton repo `chatapp`
3. Dans **"Environment Variables"**, ajoute :

| Nom | Valeur |
|-----|--------|
| `NEXT_PUBLIC_SUPABASE_URL` | ton URL supabase (https://xxx.supabase.co) |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | ta clé anon public |
| `SUPABASE_SERVICE_ROLE_KEY` | ta clé service_role |
| `RESEND_API_KEY` | ta clé Resend (re_...) |
| `NEXT_PUBLIC_APP_URL` | https://ton-app.vercel.app (à compléter après déploiement) |

4. Clique **"Deploy"** !
5. Une fois déployé, copie l'URL de ton app et mets-la dans `NEXT_PUBLIC_APP_URL`

### Étape 5 : C'est en ligne ! 🎉

Ton app est accessible sur l'URL Vercel.

---

## ✨ Fonctionnalités

- ✅ Inscription par email avec code à 6 chiffres
- ✅ Connexion sécurisée
- ✅ Messages privés en temps réel
- ✅ Envoi de photos
- ✅ Création de groupes
- ✅ Interface mobile responsive

## 🛠️ Technologies

- **Next.js 14** - Framework React
- **Supabase** - Base de données + Auth + Temps réel + Stockage
- **Resend** - Envoi d'emails
- **Vercel** - Hébergement
- **Tailwind CSS** - Styles
